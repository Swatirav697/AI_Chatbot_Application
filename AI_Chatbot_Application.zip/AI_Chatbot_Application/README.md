# Nova AI Chatbot

A beginner-friendly AI chatbot web application built with **Python, Flask, HTML, CSS, JavaScript and the OpenAI API**.

## Features
- Modern responsive chat interface
- AI-generated answers through the OpenAI Responses API
- Multi-turn conversation context
- New Chat button and suggestion prompts
- Loading indicator and clear error messages
- API key kept on the server in a `.env` file

## Requirements
- Python 3.10 or newer
- Internet connection
- An OpenAI API key with API access and billing configured

## Run on Windows (VS Code)
1. Extract the ZIP and open the `AI_Chatbot_Application` folder in VS Code.
2. Open the terminal in VS Code.
3. Create a virtual environment:

   ```bash
   python -m venv venv
   ```

4. Activate it:

   ```bash
   venv\\Scripts\\activate
   ```

5. Install packages:

   ```bash
   pip install -r requirements.txt
   ```

6. Copy `.env.example` and rename the copy to `.env`.
7. Open `.env` and replace `put_your_api_key_here` with your own API key. Do not share or upload this key.
8. Start the application:

   ```bash
   python app.py
   ```

9. Open `http://127.0.0.1:5000` in your browser.

## Run on macOS / Linux
Activate the virtual environment with:

```bash
source venv/bin/activate
```

Then install requirements, configure `.env`, and run `python app.py`.

## Important
- The chatbot requires an OpenAI API key. ChatGPT subscriptions and API billing are separate.
- API usage may incur charges. Check your API usage and limits.
- Never put the API key in JavaScript, HTML, GitHub, or a public repository.
- For deployment, turn off Flask debug mode and use a production WSGI server.

## Project structure

```text
AI_Chatbot_Application/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```
