import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024

API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.5")
client = OpenAI(api_key=API_KEY) if API_KEY else None

SYSTEM_INSTRUCTIONS = """
You are Nova, a friendly and helpful AI assistant.
Give clear, accurate, beginner-friendly answers.
Use simple language and organized steps when useful.
If you are unsure, say so rather than inventing facts.
"""

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    history = data.get("history", [])

    if not message:
        return jsonify({"error": "Please enter a message."}), 400
    if len(message) > 8000:
        return jsonify({"error": "Message is too long. Please keep it under 8,000 characters."}), 400
    if client is None:
        return jsonify({"error": "API key is missing. Add OPENAI_API_KEY to your .env file and restart the app."}), 503

    # Keep only a small, safe conversation window from the browser.
    conversation = []
    if isinstance(history, list):
        for item in history[-12:]:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            content = item.get("content")
            if role in ("user", "assistant") and isinstance(content, str):
                conversation.append({"role": role, "content": content[:8000]})
    conversation.append({"role": "user", "content": message})

    try:
        response = client.responses.create(
            model=MODEL,
            instructions=SYSTEM_INSTRUCTIONS,
            input=conversation,
        )
        answer = (response.output_text or "").strip()
        if not answer:
            answer = "I couldn't generate a response. Please try again."
        return jsonify({"reply": answer})
    except Exception as exc:
        # Avoid exposing credentials or internal details to the browser.
        print(f"OpenAI API error: {type(exc).__name__}: {exc}")
        return jsonify({"error": "The AI service could not complete your request. Check your API key, model name, internet connection, and API billing, then try again."}), 502

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
