const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const messages = document.getElementById("messages");
const sendButton = document.getElementById("sendButton");
const newChatButton = document.getElementById("newChat");
let history = [];
let busy = false;

function addMessage(role, content) {
  const welcome = document.getElementById("welcome");
  if (welcome) welcome.remove();
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "You" : "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  // textContent prevents model output from being interpreted as HTML.
  bubble.textContent = content;
  row.append(avatar, bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
  return row;
}

async function sendMessage(text) {
  if (busy || !text.trim()) return;
  busy = true;
  sendButton.disabled = true;
  addMessage("user", text);
  const previousHistory = history.slice();
  history.push({role: "user", content: text});
  const typing = document.createElement("div");
  typing.className = "typing";
  typing.textContent = "Nova is thinking...";
  messages.appendChild(typing);
  messages.scrollTop = messages.scrollHeight;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: text, history: previousHistory})
    });
    const data = await response.json();
    typing.remove();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    history.push({role: "assistant", content: data.reply});
    addMessage("assistant", data.reply);
  } catch (error) {
    typing.remove();
    // Keep the user message visible, but do not add a failed turn to conversation context.
    history = previousHistory;
    addMessage("assistant", `Sorry, ${error.message}`);
  } finally {
    busy = false;
    sendButton.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text || busy) return;
  input.value = "";
  input.style.height = "auto";
  sendMessage(text);
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 140) + "px";
});
input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".suggestion").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.textContent));
});

newChatButton.addEventListener("click", () => {
  if (busy) return;
  history = [];
  messages.innerHTML = `
    <div class="welcome" id="welcome">
      <div class="welcome-symbol">✦</div>
      <h2>How can I help you today?</h2>
      <p>I'm Nova, your AI assistant. Ask a question or choose a suggestion below.</p>
      <div class="suggestions">
        <button class="suggestion">Explain Python in simple words</button>
        <button class="suggestion">Give me project ideas for MSc IT</button>
        <button class="suggestion">Help me prepare for an interview</button>
        <button class="suggestion">Write a professional email</button>
      </div>
    </div>`;
  document.querySelectorAll(".suggestion").forEach(button =>
    button.addEventListener("click", () => sendMessage(button.textContent))
  );
});
